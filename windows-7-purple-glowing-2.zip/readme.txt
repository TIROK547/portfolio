﻿=== Windows 7 Purple Glowing 2 Cursor Set ===

By: Cursor Mania (http://www.rw-designer.com/user/111242)

Download: http://www.rw-designer.com/cursor-set/windows-7-purple-glowing-2

Author's description:

A light cursor with purple glowing and purple charge icons.

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.